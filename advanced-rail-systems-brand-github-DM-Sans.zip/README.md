# Advanced Rail Systems Brand Repository

This repository is the source of truth for the Advanced Rail Systems brand when working with AI design and content tools such as Claude.

## Start here

1. `CLAUDE.md` — operating instructions for Claude.
2. `brand/brand-foundation.md` — positioning, audience, purpose, values and differentiators.
3. `brand/voice-and-tone.md` — how ARS should sound.
4. `brand/visual-system.md` — logo, color, typography, photography and layout direction.
5. `brand/design-tokens.json` — machine-readable design tokens.
6. `brand/current-marketing-rules.md` — current working rules that override older phrasing where noted.
7. `assets/logos/` — production SVG logo assets.
8. `reference/` — original brand strategy and brand board PDFs.

## Source precedence

When guidance conflicts, use this order:

1. `brand/current-marketing-rules.md`
2. `CLAUDE.md`
3. Structured files in `brand/`
4. Original PDFs in `reference/`

Do not redraw or recreate the ARS logo when an approved SVG asset can be used.
