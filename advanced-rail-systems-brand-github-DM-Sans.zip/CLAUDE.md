# CLAUDE.md — Advanced Rail Systems Brand Instructions

You are working for Advanced Rail Systems (ARS), a rail-industry company serving railroad professionals, operations leaders, engineering managers, signal teams, maintenance teams, technology teams, ports, industrial rail operations and short lines.

Treat this repository as the brand source of truth.

## Brand character

ARS should feel:
- Practical
- Dependable
- Responsive
- Knowledgeable
- Straightforward
- Collaborative
- Relational
- Confident
- Curious

ARS should not feel:
- Flashy
- Overly corporate
- Buzzword-driven
- Complicated
- Arrogant
- Transactional
- Futuristic for its own sake
- Unprofessional

## Writing standard

Write for experienced railroad professionals. Prioritize technical clarity, concrete information, information density, systems thinking and quiet confidence over marketing language.

Every sentence should teach, clarify, establish credibility or advance the story.

Avoid empty claims and generic adjectives. Explain:
- why a capability exists,
- what it does,
- who it is for,
- when it should be used,
- how products relate to one another,
- and how a customer can grow from a single component into a connected system.

Use concise paragraphs and complete thoughts.

Do not use generic marketing phrases such as:
- industry-leading
- innovative
- best-in-class
- state-of-the-art
- trusted partner as an unsupported claim
- cutting-edge
- designed to meet your needs
- every rail yard is different
- tailored solutions
- rugged or reliable unless the specific context supports the claim

## Terminology override

Do not use “yard automation” or “automation” as a broad marketing category.

Prefer:
- yard optimization
- better yard performance
- connected yard operations
- modernizing yard operations
- rail yard systems
- practical yard technology

When referring specifically to switch equipment, use “automatic switch machines” or “power switch machines” as appropriate.

If the original July 2026 brand documents use “automation” broadly, follow this newer terminology rule instead.


## Typography override

Use **DM Sans as the primary ARS brand typeface** for new marketing and design work. Use the family consistently across headlines, subheads, body copy, labels and captions, creating hierarchy through weight, size, spacing and color.

Older source documents reference Urbane, Franklin Gothic and Century Gothic. DM Sans supersedes those recommendations for new work.

Do not recreate or retype the approved ARS logo in DM Sans; always use the supplied logo artwork.

## Visual direction

The visual system should feel clean, industrial and modern without becoming trendy or futuristic.

Use:
- strong contrast,
- black, white, navy and electric blue,
- real railroad environments,
- real railroaders,
- minimal compositions,
- purposeful movement inspired by rail geometry.

Do not over-style railroad photography. Avoid obvious AI aesthetics, dramatic cinematic grading, fake perfection or implausible rail environments.

Use approved logo SVGs from `assets/logos/` rather than recreating the logo.

## Layout behavior

Favor:
- large negative space,
- confident typography,
- simple geometric divisions,
- dark navy fields,
- white fields,
- electric blue accents,
- restrained gradients,
- rail-inspired arcs/curves where useful.

Avoid:
- excessive glow,
- sci-fi UI,
- cluttered card grids,
- generic tech-company visuals,
- decorative effects without operational meaning.

## Before producing work

Read the relevant files in `brand/`. For high-visibility brand work, consult the original PDFs in `reference/` as well.
