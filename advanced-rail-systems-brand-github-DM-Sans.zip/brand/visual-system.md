# Visual System

## Core visual themes

The ARS visual system is:
- clean and industrial,
- modern without feeling trendy,
- high-contrast,
- minimal,
- confident without arrogance.

Photography should emphasize real railroad environments and real railroaders.

Movement and graphic geometry can take cues from rail curvature and track geometry.

## Logo system

Approved assets are in `assets/logos/`.

Available files:
- `ars-primary-full-color.svg`
- `ars-primary-semi-reverse.svg`
- `ars-stacked-full-color.svg`
- `ars-stacked-semi-reverse.svg`
- `ars-icon-full-color.svg`

Use the primary logo by default when horizontal space permits.
Use stacked variants for narrower compositions.
Use semi-reverse variants on dark backgrounds.
Use the icon only when the brand is already established in context or space is constrained.

Do not redraw, retype, stretch, distort, recolor or modify the logo artwork.

## Color palette

### Core
- Electric Blue — `#2075D8`
- Black — `#0A0A0A`
- Deep Blue — `#144AA4`
- Cool Gray — `#8F94A6`
- Pale Gray — `#E9E8F2`
- Slate — `#333E5A`
- Navy — `#0C2A68`
- Deep Navy — `#051334`

### Secondary accents shown on the August 2026 brand board
Use sparingly:
- Lime — `#D2EA1E`
- Orange — `#D65F2B`
- Amber — `#ED8F07`

These secondary colors are accents, not replacements for the blue/navy core.

## Typography

### Primary brand typeface
- **DM Sans** — primary typeface for ARS marketing and brand communications.

Use DM Sans across:
- headlines,
- subheads,
- body copy,
- captions,
- labels,
- digital graphics,
- presentations,
- web layouts.

Use weight, scale, spacing and color to establish hierarchy rather than introducing multiple font families. Bold and semibold weights work well for major headlines and emphasis; regular and medium weights should carry supporting and body copy.

The approved ARS logo remains artwork and must not be retyped or recreated in DM Sans.

Older brand documents reference Urbane, Franklin Gothic and Century Gothic. For new work, **DM Sans supersedes those recommendations** unless a specific legacy asset needs to be matched.

Do not redistribute font files through this repository.

## Photography

Prefer:
- real yards,
- real track,
- real railroad equipment,
- real employees and customers when available,
- natural daylight,
- documentary credibility,
- realistic industrial conditions.

Avoid:
- over-darkened cinematic grading,
- excessive depth-of-field effects,
- unrealistic spotless yards,
- fake futuristic control-room aesthetics,
- generic stock imagery when real ARS imagery is available,
- visible AI artifacts.

## Graphic style

Use:
- white or deep navy backgrounds,
- electric blue as the primary accent,
- clear scale hierarchy,
- generous whitespace,
- restrained rail-inspired curves,
- clean product isolation when showing equipment,
- system diagrams that clarify relationships.

Avoid decorative complexity that competes with technical content.
