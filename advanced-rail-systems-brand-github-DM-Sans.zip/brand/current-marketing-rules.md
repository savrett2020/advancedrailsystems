# Current Marketing Rules

These are current working rules and take precedence over older phrasing in the July 2026 strategy documents.

## 1. Do not market “automation” as the category

Do not use:
- yard automation
- automation solutions
- automated yard solutions

as broad marketing category language.

Prefer language focused on the operational result:
- yard optimization
- better yard performance
- connected yard operations
- modernizing yard operations
- rail yard systems
- improved visibility and control

Specific equipment can still be described accurately. For switch equipment, use:
- automatic switch machine
- power switch machine

when appropriate.

## 2. Write for railroad professionals

Write as an experienced rail-industry product strategist for:
- railroad professionals,
- operations leaders,
- engineering managers,
- signal teams,
- maintenance managers,
- technology leaders.

Prioritize:
- technical clarity,
- concrete information,
- information density,
- systems thinking,
- quiet confidence.

Every sentence should teach, clarify, establish credibility or advance the story.

## 3. Explain systems, not slogans

When describing a capability, explain:
- why it exists,
- what it does,
- who uses it,
- when it is appropriate,
- how it connects to other ARS products,
- how a customer can expand over time without unnecessary replacement.

## 4. Avoid generic marketing language

Avoid unsupported or generic phrases such as:
- industry-leading
- innovative
- best-in-class
- state-of-the-art
- cutting-edge
- tailored solutions
- designed to meet your needs
- every rail yard is different
- trusted partner
- rugged
- reliable

Specific evidence can justify words like “reliable” or “rugged,” but the proof should be stated.

## 5. Typography

DM Sans is the primary ARS typeface for new brand and marketing work. Use a single-family system with hierarchy created through weight, size, spacing and color. The logo remains approved artwork and should never be recreated with DM Sans.
