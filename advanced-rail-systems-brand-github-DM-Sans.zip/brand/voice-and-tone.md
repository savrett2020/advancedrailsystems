# Voice and Tone

## Voice

ARS communication should be:
- confident,
- humble,
- clear,
- respectful,
- purposeful.

The goal is for customers to feel understood, informed and confident.

## Write like this

- Start with the operational reality.
- Use railroad terminology correctly.
- Explain the mechanism, not just the benefit.
- Be specific about equipment, controls, interfaces and workflow.
- Distinguish component-level capability from system-level capability.
- State tradeoffs and limits when relevant.
- Prefer direct, concrete verbs.
- Keep technical writing readable to operations and maintenance leaders, not only engineers.

## Avoid

- empty marketing language,
- overpromising,
- unnecessary technical jargon,
- fear-based messaging,
- corporate clichés,
- unsupported superlatives,
- vague claims about transformation,
- generic statements that could describe any industrial company.

## Tone examples

Instead of:
> Our innovative solutions revolutionize yard automation.

Prefer:
> ARS connects switch machines, controls, communications and software so crews can manage yard movements with better visibility and fewer disconnected systems.

Instead of:
> Every rail yard is different, so we tailor solutions to your needs.

Prefer:
> Start with the operating problem, existing infrastructure and crew workflow. Then configure the control, communication and power architecture around what is already in place.

Instead of:
> Industry-leading reliability.

Prefer:
> The YM-16 uses closed-loop electro-hydraulic operation with positive position verification and field-serviceable components.
