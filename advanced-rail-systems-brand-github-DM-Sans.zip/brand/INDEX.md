# Brand File Index

Use this file to decide what to read.

| Need | File |
|---|---|
| Overall AI behavior | `/CLAUDE.md` |
| Company positioning, audience, differentiators | `/brand/brand-foundation.md` |
| Copywriting and messaging | `/brand/voice-and-tone.md` |
| Current terminology and writing overrides | `/brand/current-marketing-rules.md` |
| Logo, color, typography, photography | `/brand/visual-system.md` |
| Machine-readable colors/type | `/brand/design-tokens.json` |
| Approved SVG logos | `/assets/logos/` |
| Original strategy deck | `/reference/ARS_Brand-Strategy-Playbook_202607.pdf` |
| Original brand board | `/reference/ARS_Rebrand_Brand-Board_20260806.pdf` |
